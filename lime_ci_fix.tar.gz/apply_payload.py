# -*- coding: utf-8 -*-
"""Декодер патч-пакета CI. Запуск из корня клона: python apply_payload.py PAYLOAD.txt"""
import base64, os, sys
payload = open(sys.argv[1], encoding='utf-8').read()
for chunk in payload.split('=== FILE: ')[1:]:
    header, b64 = chunk.split(' ===\n', 1)
    name = header.split(' (')[0].strip()
    data = base64.b64decode(b64.strip())
    d = os.path.dirname(name)
    if d: os.makedirs(d, exist_ok=True)
    with open(name, 'wb') as f: f.write(data)
    print('WROTE %s (%d bytes)' % (name, len(data)))
