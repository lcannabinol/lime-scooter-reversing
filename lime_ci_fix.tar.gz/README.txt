lime_ci_fix — починка CI (2 файла)
==================================
Содержимое архива:
  apply_payload.py  - декодер (запускать из корня клона)
  PAYLOAD.txt       - base64 двух файлов патча

Файлы, которые создаст декодер в корне клона:
  .pylintrc                      - конфиг pylint для Ghidra/Jython-скриптов
  .github/workflows/pylint.yml   - исправленный workflow (setup-python@v5, Python 3.9/3.10/3.11)

Что чинит:
  1) "Version 3.9 with arch x64 not found" - устаревший actions/setup-python@v3 + снятая с поддержки 3.8
  2) волна E0602/E0401 на LimeRE_Helper.py - Ghidra API не виден CPython-линтеру;
     в .pylintrc они объявлены additional-builtins/ignored-modules, включены только реальные ошибки E.

Проверено локально: pylint --rcfile=.pylintrc по всем *.py репо -> exit 0, чисто.

Установка (из D:/lime/lime-scooter-reversing):
  python apply_payload.py PAYLOAD.txt
  git add .pylintrc .github/workflows/pylint.yml
  git commit -m "CI: fix lint job (setup-python@v5, pylintrc for Ghidra scripts)"
  git push origin master
